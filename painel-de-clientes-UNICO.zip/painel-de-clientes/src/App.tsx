import { useState, useEffect } from 'react';
import { SearchBar } from './components/SearchBar';
import { ClientCard } from './components/ClientCard';
import { ClientChart } from './components/ClientChart';
import './App.css';

interface Client {
  id: number;
  name: string;
  email: string;
  phone: string;
  address: { city: string };
  company: { name: string };
}

function App() {
  const [clients, setClients] = useState<Client[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState<string>('');

  useEffect(() => {
    const controller = new AbortController();

    const loadClients = async () => {
      try {
        const response = await fetch('https://jsonplaceholder.typicode.com/users', {
          signal: controller.signal,
        });

        if (!response.ok) {
          throw new Error('Falha ao carregar os dados dos clientes.');
        }

        const data: Client[] = await response.json();
        setClients(data);
      } catch (err) {
        if (err instanceof DOMException && err.name === 'AbortError') return;
        setError(err instanceof Error ? err.message : 'Não foi possível carregar os clientes.');
      } finally {
        if (!controller.signal.aborted) setLoading(false);
      }
    };

    loadClients();
    return () => controller.abort();
  }, []);

  const filteredClients = clients.filter((client) =>
    client.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="app-container">
      <header className="app-header">
        <h1>Painel de Clientes</h1>
      </header>

      {loading && <div className="status-message">Carregando dados dos clientes...</div>}
      
      {error && <div className="status-message error-message">Erro: {error}</div>}

      {!loading && !error && (
        <main className="app-content">
          <SearchBar searchTerm={searchTerm} setSearchTerm={setSearchTerm} />
          
          <ClientChart clients={filteredClients} />

          <section className="client-grid">
            {filteredClients.length > 0 ? (
              filteredClients.map((client) => (
                <ClientCard key={client.id} client={client} />
              ))
            ) : (
              <p className="no-results">Nenhum cliente encontrado com este nome.</p>
            )}
          </section>
        </main>
      )}
    </div>
  );
}

export default App;
