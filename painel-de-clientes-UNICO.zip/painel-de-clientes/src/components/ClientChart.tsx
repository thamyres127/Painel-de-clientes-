import React from 'react';
import { Bar } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

interface ClientChartProps {
  clients: Array<{ address: { city: string } }>;
}

export const ClientChart: React.FC<ClientChartProps> = ({ clients }) => {
  const cityCounts: { [key: string]: number } = {};
  clients.forEach((client) => {
    const city = client.address.city;
    cityCounts[city] = (cityCounts[city] || 0) + 1;
  });

  const data = {
    labels: Object.keys(cityCounts),
    datasets: [
      {
        label: 'Quantidade de Clientes',
        data: Object.values(cityCounts),
        backgroundColor: 'rgba(54, 162, 235, 0.6)',
        borderColor: 'rgba(54, 162, 235, 1)',
        borderWidth: 1,
      },
    ],
  };

  const options = {
    responsive: true,
    plugins: {
      legend: { position: 'top' as const },
      title: { display: true, text: 'Distribuição de Clientes por Cidade' },
    },
  };

  return (
    <div className="chart-container">
      <Bar data={data} options={options} />
    </div>
  );
};
