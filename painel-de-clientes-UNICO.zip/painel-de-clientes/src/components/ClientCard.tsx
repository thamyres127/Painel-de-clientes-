import React from 'react';

interface ClientProps {
  client: {
    id: number;
    name: string;
    email: string;
    phone: string;
    address: { city: string };
    company: { name: string };
  };
}

export const ClientCard: React.FC<ClientProps> = ({ client }) => {
  return (
    <div className="client-card">
      <h3>{client.name}</h3>
      <p><strong>E-mail:</strong> {client.email}</p>
      <p><strong>Telefone:</strong> {client.phone}</p>
      <p><strong>Cidade:</strong> {client.address.city}</p>
      <p><strong>Empresa:</strong> {client.company.name}</p>
    </div>
  );
};
