# Painel de Clientes 📊

Painel responsivo em React + TypeScript para consulta, busca e visualização de clientes.

## Tecnologias
- React 18
- TypeScript
- Vite
- Chart.js + react-chartjs-2
- HTML5 e CSS3

## Funcionalidades
- Consumo assíncrono da API pública JSONPlaceholder.
- Busca de clientes pelo nome.
- Cards com e-mail, telefone, cidade e empresa.
- Gráfico de clientes por cidade.
- Layout responsivo para desktop e mobile.
- Tratamento de erro e cancelamento da requisição ao desmontar o componente.

## Rodar localmente

```bash
npm install
npm run dev
```

Para gerar a versão de produção:

```bash
npm run build
```

A pasta `dist` será criada pelo Vite.

## Vercel / Netlify

Use estas configurações:

- **Build command:** `npm run build`
- **Publish/output directory:** `dist`
- **Install command:** `npm install`

Não é necessário colocar `node_modules` no GitHub.

## API

Os dados são carregados de:
`https://jsonplaceholder.typicode.com/users`

O projeto depende de conexão com a internet para carregar os clientes.
